from django.apps import AppConfig


class KokkConfig(AppConfig):
    name = 'chef'
