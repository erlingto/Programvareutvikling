from django.apps import AppConfig


class FridgeConfig(AppConfig):
    name = 'fridge'