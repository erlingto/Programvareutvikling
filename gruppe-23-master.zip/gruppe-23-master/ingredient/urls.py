from django.urls import re_path, path

from ingredient.views import IngredientView

app_name = "ingredient"
