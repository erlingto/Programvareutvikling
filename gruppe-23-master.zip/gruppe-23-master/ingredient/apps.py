from django.apps import AppConfig


class IngredientConfig(AppConfig):
    name = 'ingredient'
