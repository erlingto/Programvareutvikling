echo "***********************************************"
echo "***************** Install *********************"
echo "***********************************************"

echo "***********************************************"
echo "---apt update ---"
echo "***********************************************"
apt-get -y update

echo "***********************************************"
echo "---OS dependencies---"
echo "***********************************************"
apt-get -y install python3-pip
apt-get -y install python3-dev python3-setuptools
apt-get -y install git
apt-get -y install supervisor
# .....
# .....
# .....
# .....

echo "***********************************************"
echo "--- install dependencies (including django) ---"
echo "***********************************************"
pip install --upgrade pip
pip install -r requirements.txt
pip freeze

echo "***********************************************"
echo "--- Database                                ---"
echo "***********************************************"
#YOLO SQLITE
sed -i 's/postgresql_psycopg2/sqlite3/' matega/settings.py
sed -i 's/andreas/andrerl_matega/' matega/settings.py
sed -i "s/: 'matega'/: 'andrerl_matega'/" matega/settings.py

echo "***********************************************"
echo "--- Tests                                   ---"
echo "***********************************************"
coverage run --source=fridge,recipe,matega ./manage.py test
./manage.py test

echo "***********************************************"
echo "--- Database revert                         ---"
echo "***********************************************"
sed -i 's/sqlite3/postgresql_psycopg2/' matega/settings.py
sed -i "s/'USER': 'andrerl_matega'/'USER': 'andreas'/" matega/settings.py
sed -i "s/'NAME': 'andrerl_matega'/:'NAME': 'matega'/" matega/settings.py

echo "***********************************************"
echo "--- Misc                                    ---"
echo "***********************************************"
sed -i 's/DEBUG = True/DEBUG = False/' matega/settings.py